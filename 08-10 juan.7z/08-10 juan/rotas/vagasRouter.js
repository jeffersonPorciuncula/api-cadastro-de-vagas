// Importar o express, para utilizar o Router
import express from 'express'
import {  criarvaga, listarvaga, atualizarvaga, apagarvaga, listarvagaPorId, listarvagaPorCargo } from '../controllers/vagasController.js'
const router = express.Router()

router.get('/localizacao/:cidade', listarvaga)
router.get('/vagas/:id', listarvagaPorId)
router.post('/vagas', criarvaga)
router.put('/vagas/:id', atualizarvaga)
router.delete('/vagas/:id', apagarvaga)
router.get('/vagas', listarvaga)
router.get('/cargo/:cargo', listarvagaPorCargo)

// Exportar o router pra importar no app
export default router