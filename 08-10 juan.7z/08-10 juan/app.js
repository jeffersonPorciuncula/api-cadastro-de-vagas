///iniciar servidor
import express from 'express'
import vagasRouter from './rotas/vagasRouter.js'
const app = express()
import  sequelize  from './database.js'

try{
    await sequelize.sync();
} catch (erro) {
    console.log(erro)
}


// permitir que a api receba JSON
app.use(express.json())
app.use(vagasRouter)

app.use(vagasRouter)

app.listen(3000, () => console.log('rodando'))