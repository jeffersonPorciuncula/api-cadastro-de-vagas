import sequelize from '../database.js'
import { DataTypes } from 'sequelize'

const Vagas = sequelize.define('Vagas', {
    id: {
        type: DataTypes.INTEGER,
        // allowNull: false,
        primaryKey: true, 
        autoIncrement: true
    },
    titulo: {
        type: DataTypes.STRING    
    },
    descricao: {
        type: DataTypes.STRING    
    },
    cargo: {
        type: DataTypes.STRING 
    },
    cidade: {
        type: DataTypes.STRING 
    },
    salario: {
        type: DataTypes.INTEGER
    }
})

// Verificar se existe a tabela, se não existir vai criar
Vagas.sync()

export { Vagas }