// Importar a conexão do banco de dados
import conexao from '../database.js'
import {Vagas} from "../models/vagas.js"

const criarvaga = async (req, res) => {
    try {
        const { titulo, descricao, cargo, cidade} = req.body
        if (!titulo || !descricao || !cargo || !cidade) {
            // Faltam dados
            return res.status(404).send({ mensagem: 'Favor informar titulo, descrição, cargo e cidade' })
        }
        const vaga = await Vagas.create({
        titulo, descricao, cargo, cidade
        });

        res.status(201).send({ mensagem: 'vaga inserido' })

    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}

const listarvaga = async (req, res) => {
    try {
        // Rodar um comando de SELECT no banco de dados
        const resultado = await Vagas.findAll()
        res.status(200).send({ resultado})
    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}
const listarvagaPorId = async (req, res) => {
    try {
        // Rodar um comando de SELECT no banco de dados
        const id = req.params.id;
        const resultado = await Vagas.findAll({ where: { id } })
        res.status(200).send({ resultado: resultado.rows })
    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}

const listarvagaPorCargo = async (req, res) => {
    try {
         const { cargo } = req.params.cargo
        // Rodar um comando de SELECT no banco de dados
        const resultado = await Vagas.findAll(({ where: { cargo } }))
        res.status(200).send({ resultado: resultado.rows })
    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}

const atualizarvaga = async (req, res) => {
    try {
        const id = req.params.id
        const { titulo, categoria } = req.body
        const resultado = await conexao.query(`UPDATE vagas SET titulo = '${titulo}', categoria = '${categoria}' WHERE id = ${id}`)
        res.status(200).send({ mensagem: resultado.rows })
    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}

const apagarvaga = async (req, res) => {
    try {
        const id = req.params.id
        await conexao.query(`DELETE FROM vagas WHERE id = ${id}`)
        res.status(200).send({ mensagem: 'vaga apagado com sucesso' })
    } catch (erro) {
        console.log(erro)
        res.status(500).send({ mensagem: 'Erro interno' })
    }
}

// Exportar controllers para importar nas rotas
export { criarvaga, listarvaga, atualizarvaga, apagarvaga, listarvagaPorId, listarvagaPorCargo }