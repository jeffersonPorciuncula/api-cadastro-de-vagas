import { Sequelize } from 'sequelize'

const conexao = new Sequelize('postgresql://jefferson:2SPlNsTG7LRINJa76ocvYw@winged-quacker-1695.jxf.cockroachlabs.cloud:26257/defaultdb?sslmode=verify-full')

try {
    await conexao.authenticate()
    console.log('Conectado com sucesso')
} catch (error) {
    console.error('Erro ao conectar', error)
}

export default conexao
